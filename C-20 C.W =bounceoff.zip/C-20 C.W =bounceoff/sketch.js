var fixRECT;
var movRECT;

function setup() {
  createCanvas(800,400);
  fixRECT=createSprite(100, 500, 50, 50);
  fixRECT.shapeColor="yellow";
  fixRECT.velocityX=4;
  movRECT=createSprite(300,500,40,90);
  movRECT.velocityX=-4;
  movRECT.shapeColor="red";
}

function draw() {
  background(180);  



  if(fixRECT.x-movRECT.x<fixRECT.width/2+movRECT.width/2
    &&movRECT.x-fixRECT.x<fixRECT.width/2+movRECT.width/2)
  {
fixRECT.velocityX=fixRECT.velocityX*(-1);
movRECT.velocityX=movRECT.velocityX*(-1);
  }


   if (fixRECT.y-movRECT.y<fixRECT.height/2+movRECT.height/2
    &&movRECT.y-fixRECT.y<fixRECT.height/2+movRECT.height/2)
    {
      fixRECT.velocityY=fixRECT.velocityY*(-1);
      movRECT.velocityY=movRECT.velocityY*(-1);
  }
 
  drawSprites();
}